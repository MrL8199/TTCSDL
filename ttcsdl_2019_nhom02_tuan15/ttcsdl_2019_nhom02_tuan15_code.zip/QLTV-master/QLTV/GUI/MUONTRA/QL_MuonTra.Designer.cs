﻿namespace QLTV.GUI.MUONTRA
{
    partial class QL_MuonTra
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.tbMaKeSach1 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.tbMaDauSach1 = new System.Windows.Forms.TextBox();
            this.tbTTCuonSach1 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.tbTinhTrang1 = new System.Windows.Forms.TextBox();
            this.tbSoTrang1 = new System.Windows.Forms.TextBox();
            this.tbTenSach1 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.gbMuonSach = new System.Windows.Forms.GroupBox();
            this.tbCuonSach1 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.tbNgayHanTra1 = new System.Windows.Forms.DateTimePicker();
            this.tbNgayMuon1 = new System.Windows.Forms.DateTimePicker();
            this.tbNhanVien1 = new System.Windows.Forms.TextBox();
            this.tbMaThe1 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tbMaKeSach2 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.tbMaDauSach2 = new System.Windows.Forms.TextBox();
            this.tbTTCuonSach2 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.tbTinhTrang2 = new System.Windows.Forms.TextBox();
            this.tbSoTrang2 = new System.Windows.Forms.TextBox();
            this.tbTenSach2 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.tbNgayTra2 = new System.Windows.Forms.DateTimePicker();
            this.tbCuonSach2 = new System.Windows.Forms.TextBox();
            this.tbNhanVien2 = new System.Windows.Forms.TextBox();
            this.tbMaThe2 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.label12 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.gbMuonSach.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.groupBox7.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(-12, 4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1192, 607);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox9);
            this.tabPage1.Controls.Add(this.groupBox3);
            this.tabPage1.Controls.Add(this.button4);
            this.tabPage1.Controls.Add(this.button3);
            this.tabPage1.Controls.Add(this.button2);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Controls.Add(this.gbMuonSach);
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1184, 574);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Phiếu Mượn Sách";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.tbMaKeSach1);
            this.groupBox9.Controls.Add(this.label9);
            this.groupBox9.Controls.Add(this.tbMaDauSach1);
            this.groupBox9.Controls.Add(this.tbTTCuonSach1);
            this.groupBox9.Controls.Add(this.label17);
            this.groupBox9.Controls.Add(this.tbTinhTrang1);
            this.groupBox9.Controls.Add(this.tbSoTrang1);
            this.groupBox9.Controls.Add(this.tbTenSach1);
            this.groupBox9.Controls.Add(this.label16);
            this.groupBox9.Controls.Add(this.label15);
            this.groupBox9.Controls.Add(this.label6);
            this.groupBox9.Controls.Add(this.label5);
            this.groupBox9.Location = new System.Drawing.Point(8, 262);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(371, 316);
            this.groupBox9.TabIndex = 14;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Thông tin Cuốn sách";
            // 
            // tbMaKeSach1
            // 
            this.tbMaKeSach1.Location = new System.Drawing.Point(145, 253);
            this.tbMaKeSach1.Name = "tbMaKeSach1";
            this.tbMaKeSach1.Size = new System.Drawing.Size(205, 28);
            this.tbMaKeSach1.TabIndex = 12;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(13, 256);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(106, 21);
            this.label9.TabIndex = 11;
            this.label9.Text = "Mã Kệ Sách:";
            // 
            // tbMaDauSach1
            // 
            this.tbMaDauSach1.Location = new System.Drawing.Point(145, 211);
            this.tbMaDauSach1.Name = "tbMaDauSach1";
            this.tbMaDauSach1.Size = new System.Drawing.Size(205, 28);
            this.tbMaDauSach1.TabIndex = 10;
            // 
            // tbTTCuonSach1
            // 
            this.tbTTCuonSach1.Location = new System.Drawing.Point(145, 37);
            this.tbTTCuonSach1.Name = "tbTTCuonSach1";
            this.tbTTCuonSach1.Size = new System.Drawing.Size(205, 28);
            this.tbTTCuonSach1.TabIndex = 9;
            this.tbTTCuonSach1.TextChanged += new System.EventHandler(this.tbTTCuonSach1_TextChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(15, 214);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(116, 21);
            this.label17.TabIndex = 8;
            this.label17.Text = "Mã Đầu Sách:";
            // 
            // tbTinhTrang1
            // 
            this.tbTinhTrang1.Location = new System.Drawing.Point(145, 170);
            this.tbTinhTrang1.Name = "tbTinhTrang1";
            this.tbTinhTrang1.Size = new System.Drawing.Size(205, 28);
            this.tbTinhTrang1.TabIndex = 6;
            // 
            // tbSoTrang1
            // 
            this.tbSoTrang1.Location = new System.Drawing.Point(145, 123);
            this.tbSoTrang1.Name = "tbSoTrang1";
            this.tbSoTrang1.Size = new System.Drawing.Size(205, 28);
            this.tbSoTrang1.TabIndex = 5;
            // 
            // tbTenSach1
            // 
            this.tbTenSach1.Location = new System.Drawing.Point(145, 81);
            this.tbTenSach1.Name = "tbTenSach1";
            this.tbTenSach1.Size = new System.Drawing.Size(205, 28);
            this.tbTenSach1.TabIndex = 4;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(13, 173);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(103, 21);
            this.label16.TabIndex = 3;
            this.label16.Text = "Tình Trạng :";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(15, 126);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(83, 21);
            this.label15.TabIndex = 2;
            this.label15.Text = "Số Trang:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(13, 84);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(85, 21);
            this.label6.TabIndex = 1;
            this.label6.Text = "Tên Sách:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 37);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(126, 21);
            this.label5.TabIndex = 0;
            this.label5.Text = "Mã Cuốn Sách:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.dataGridView1);
            this.groupBox3.Location = new System.Drawing.Point(385, 262);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(800, 309);
            this.groupBox3.TabIndex = 13;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Danh sách Phiếu mượn";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(6, 21);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(793, 285);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(958, 221);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(87, 35);
            this.button4.TabIndex = 12;
            this.button4.Text = "Hủy";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(807, 221);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(87, 35);
            this.button3.TabIndex = 11;
            this.button3.Text = "Xóa";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(653, 221);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(87, 35);
            this.button2.TabIndex = 10;
            this.button2.Text = "Sửa";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(502, 221);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(87, 35);
            this.button1.TabIndex = 9;
            this.button1.Text = "Mượn";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radioButton2);
            this.groupBox2.Controls.Add(this.radioButton1);
            this.groupBox2.Controls.Add(this.textBox5);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Location = new System.Drawing.Point(8, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(371, 212);
            this.groupBox2.TabIndex = 8;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Tìm Kiếm Phiếu Mượn";
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(165, 138);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(120, 25);
            this.radioButton2.TabIndex = 3;
            this.radioButton2.Text = "Ngày Mượn";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Checked = true;
            this.radioButton1.Location = new System.Drawing.Point(165, 89);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(89, 25);
            this.radioButton1.TabIndex = 2;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Mã Thẻ";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(50, 40);
            this.textBox5.Multiline = true;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(275, 29);
            this.textBox5.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(47, 88);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(83, 21);
            this.label7.TabIndex = 0;
            this.label7.Text = "Tìm theo:";
            // 
            // gbMuonSach
            // 
            this.gbMuonSach.Controls.Add(this.tbCuonSach1);
            this.gbMuonSach.Controls.Add(this.label18);
            this.gbMuonSach.Controls.Add(this.tbNgayHanTra1);
            this.gbMuonSach.Controls.Add(this.tbNgayMuon1);
            this.gbMuonSach.Controls.Add(this.tbNhanVien1);
            this.gbMuonSach.Controls.Add(this.tbMaThe1);
            this.gbMuonSach.Controls.Add(this.label4);
            this.gbMuonSach.Controls.Add(this.label3);
            this.gbMuonSach.Controls.Add(this.label2);
            this.gbMuonSach.Controls.Add(this.label1);
            this.gbMuonSach.Location = new System.Drawing.Point(385, 3);
            this.gbMuonSach.Name = "gbMuonSach";
            this.gbMuonSach.Size = new System.Drawing.Size(803, 212);
            this.gbMuonSach.TabIndex = 7;
            this.gbMuonSach.TabStop = false;
            this.gbMuonSach.Text = "Mượn sách";
            // 
            // tbCuonSach1
            // 
            this.tbCuonSach1.Location = new System.Drawing.Point(540, 40);
            this.tbCuonSach1.Name = "tbCuonSach1";
            this.tbCuonSach1.Size = new System.Drawing.Size(171, 28);
            this.tbCuonSach1.TabIndex = 13;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(391, 43);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(126, 21);
            this.label18.TabIndex = 12;
            this.label18.Text = "Mã Cuốn Sách:";
            // 
            // tbNgayHanTra1
            // 
            this.tbNgayHanTra1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.tbNgayHanTra1.Location = new System.Drawing.Point(180, 121);
            this.tbNgayHanTra1.Name = "tbNgayHanTra1";
            this.tbNgayHanTra1.Size = new System.Drawing.Size(170, 28);
            this.tbNgayHanTra1.TabIndex = 11;
            // 
            // tbNgayMuon1
            // 
            this.tbNgayMuon1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.tbNgayMuon1.Location = new System.Drawing.Point(180, 81);
            this.tbNgayMuon1.Name = "tbNgayMuon1";
            this.tbNgayMuon1.Size = new System.Drawing.Size(170, 28);
            this.tbNgayMuon1.TabIndex = 10;
            this.tbNgayMuon1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // tbNhanVien1
            // 
            this.tbNhanVien1.Location = new System.Drawing.Point(540, 83);
            this.tbNhanVien1.Name = "tbNhanVien1";
            this.tbNhanVien1.Size = new System.Drawing.Size(171, 28);
            this.tbNhanVien1.TabIndex = 7;
            // 
            // tbMaThe1
            // 
            this.tbMaThe1.Location = new System.Drawing.Point(180, 40);
            this.tbMaThe1.Name = "tbMaThe1";
            this.tbMaThe1.Size = new System.Drawing.Size(170, 28);
            this.tbMaThe1.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(391, 86);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(120, 21);
            this.label4.TabIndex = 3;
            this.label4.Text = "Mã Nhân Viên:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(38, 127);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(118, 21);
            this.label3.TabIndex = 2;
            this.label3.Text = "Ngày Hạn Trả:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(38, 86);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 21);
            this.label2.TabIndex = 1;
            this.label2.Text = "Ngày Mượn:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(38, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 21);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mã Thẻ:";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Controls.Add(this.groupBox6);
            this.tabPage2.Controls.Add(this.button5);
            this.tabPage2.Controls.Add(this.button6);
            this.tabPage2.Controls.Add(this.button7);
            this.tabPage2.Controls.Add(this.button8);
            this.tabPage2.Controls.Add(this.groupBox4);
            this.tabPage2.Controls.Add(this.groupBox5);
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1184, 574);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Phiếu Trả Sách";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tbMaKeSach2);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.tbMaDauSach2);
            this.groupBox1.Controls.Add(this.tbTTCuonSach2);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.tbTinhTrang2);
            this.groupBox1.Controls.Add(this.tbSoTrang2);
            this.groupBox1.Controls.Add(this.tbTenSach2);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.label24);
            this.groupBox1.Location = new System.Drawing.Point(6, 251);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(371, 316);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Thông tin Cuốn sách";
            // 
            // tbMaKeSach2
            // 
            this.tbMaKeSach2.Location = new System.Drawing.Point(145, 253);
            this.tbMaKeSach2.Name = "tbMaKeSach2";
            this.tbMaKeSach2.Size = new System.Drawing.Size(205, 28);
            this.tbMaKeSach2.TabIndex = 12;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(13, 256);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(106, 21);
            this.label19.TabIndex = 11;
            this.label19.Text = "Mã Kệ Sách:";
            // 
            // tbMaDauSach2
            // 
            this.tbMaDauSach2.Location = new System.Drawing.Point(145, 211);
            this.tbMaDauSach2.Name = "tbMaDauSach2";
            this.tbMaDauSach2.Size = new System.Drawing.Size(205, 28);
            this.tbMaDauSach2.TabIndex = 10;
            // 
            // tbTTCuonSach2
            // 
            this.tbTTCuonSach2.Location = new System.Drawing.Point(145, 37);
            this.tbTTCuonSach2.Name = "tbTTCuonSach2";
            this.tbTTCuonSach2.Size = new System.Drawing.Size(205, 28);
            this.tbTTCuonSach2.TabIndex = 9;
            this.tbTTCuonSach2.TextChanged += new System.EventHandler(this.tbTTCuonSach2_TextChanged);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(15, 214);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(116, 21);
            this.label20.TabIndex = 8;
            this.label20.Text = "Mã Đầu Sách:";
            // 
            // tbTinhTrang2
            // 
            this.tbTinhTrang2.Location = new System.Drawing.Point(145, 170);
            this.tbTinhTrang2.Name = "tbTinhTrang2";
            this.tbTinhTrang2.Size = new System.Drawing.Size(205, 28);
            this.tbTinhTrang2.TabIndex = 6;
            // 
            // tbSoTrang2
            // 
            this.tbSoTrang2.Location = new System.Drawing.Point(145, 123);
            this.tbSoTrang2.Name = "tbSoTrang2";
            this.tbSoTrang2.Size = new System.Drawing.Size(205, 28);
            this.tbSoTrang2.TabIndex = 5;
            this.tbSoTrang2.TextChanged += new System.EventHandler(this.textBox7_TextChanged);
            // 
            // tbTenSach2
            // 
            this.tbTenSach2.Location = new System.Drawing.Point(145, 81);
            this.tbTenSach2.Name = "tbTenSach2";
            this.tbTenSach2.Size = new System.Drawing.Size(205, 28);
            this.tbTenSach2.TabIndex = 4;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(13, 173);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(103, 21);
            this.label21.TabIndex = 3;
            this.label21.Text = "Tình Trạng :";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(15, 126);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(83, 21);
            this.label22.TabIndex = 2;
            this.label22.Text = "Số Trang:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(13, 84);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(85, 21);
            this.label23.TabIndex = 1;
            this.label23.Text = "Tên Sách:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(13, 37);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(126, 21);
            this.label24.TabIndex = 0;
            this.label24.Text = "Mã Cuốn Sách:";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.dataGridView2);
            this.groupBox6.Location = new System.Drawing.Point(383, 251);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(838, 339);
            this.groupBox6.TabIndex = 13;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Danh sách Phiếu trả";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(0, 21);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(801, 306);
            this.dataGridView2.TabIndex = 0;
            this.dataGridView2.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellClick);
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(959, 204);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(87, 35);
            this.button5.TabIndex = 12;
            this.button5.Text = "Hủy";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(808, 204);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(87, 35);
            this.button6.TabIndex = 11;
            this.button6.Text = "Xóa";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(654, 204);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(87, 35);
            this.button7.TabIndex = 10;
            this.button7.Text = "Sửa";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(503, 204);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(87, 35);
            this.button8.TabIndex = 9;
            this.button8.Text = "Trả";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.radioButton3);
            this.groupBox4.Controls.Add(this.radioButton4);
            this.groupBox4.Controls.Add(this.textBox6);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Location = new System.Drawing.Point(6, 0);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(371, 198);
            this.groupBox4.TabIndex = 8;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Tìm Kiếm Phiếu Trả";
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(165, 138);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(100, 25);
            this.radioButton3.TabIndex = 3;
            this.radioButton3.Text = "Ngày Trả";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Checked = true;
            this.radioButton4.Location = new System.Drawing.Point(165, 89);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(89, 25);
            this.radioButton4.TabIndex = 2;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "Mã Thẻ";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(50, 40);
            this.textBox6.Multiline = true;
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(275, 29);
            this.textBox6.TabIndex = 1;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(47, 88);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(83, 21);
            this.label8.TabIndex = 0;
            this.label8.Text = "Tìm theo:";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.tbNgayTra2);
            this.groupBox5.Controls.Add(this.tbCuonSach2);
            this.groupBox5.Controls.Add(this.tbNhanVien2);
            this.groupBox5.Controls.Add(this.tbMaThe2);
            this.groupBox5.Controls.Add(this.label10);
            this.groupBox5.Controls.Add(this.label11);
            this.groupBox5.Controls.Add(this.label13);
            this.groupBox5.Controls.Add(this.label14);
            this.groupBox5.Location = new System.Drawing.Point(383, 0);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(798, 198);
            this.groupBox5.TabIndex = 7;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Trả sách";
            // 
            // tbNgayTra2
            // 
            this.tbNgayTra2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.tbNgayTra2.Location = new System.Drawing.Point(180, 86);
            this.tbNgayTra2.Name = "tbNgayTra2";
            this.tbNgayTra2.Size = new System.Drawing.Size(178, 28);
            this.tbNgayTra2.TabIndex = 10;
            // 
            // tbCuonSach2
            // 
            this.tbCuonSach2.Location = new System.Drawing.Point(553, 40);
            this.tbCuonSach2.Name = "tbCuonSach2";
            this.tbCuonSach2.Size = new System.Drawing.Size(181, 28);
            this.tbCuonSach2.TabIndex = 8;
            // 
            // tbNhanVien2
            // 
            this.tbNhanVien2.Location = new System.Drawing.Point(180, 135);
            this.tbNhanVien2.Name = "tbNhanVien2";
            this.tbNhanVien2.Size = new System.Drawing.Size(178, 28);
            this.tbNhanVien2.TabIndex = 7;
            // 
            // tbMaThe2
            // 
            this.tbMaThe2.Location = new System.Drawing.Point(180, 40);
            this.tbMaThe2.Name = "tbMaThe2";
            this.tbMaThe2.Size = new System.Drawing.Size(178, 28);
            this.tbMaThe2.TabIndex = 6;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(421, 43);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(126, 21);
            this.label10.TabIndex = 4;
            this.label10.Text = "Mã Cuốn Sách:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(38, 140);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(120, 21);
            this.label11.TabIndex = 3;
            this.label11.Text = "Mã Nhân Viên:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(38, 92);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(83, 21);
            this.label13.TabIndex = 1;
            this.label13.Text = "Ngày Trả:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(38, 43);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(72, 21);
            this.label14.TabIndex = 0;
            this.label14.Text = "Mã Thẻ:";
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.groupBox8);
            this.tabPage3.Controls.Add(this.groupBox7);
            this.tabPage3.Location = new System.Drawing.Point(4, 29);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1184, 574);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Thống Kê";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.dataGridView3);
            this.groupBox8.Location = new System.Drawing.Point(3, 308);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(1181, 270);
            this.groupBox8.TabIndex = 1;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Danh sách phiếu mượn";
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(3, 21);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowTemplate.Height = 24;
            this.dataGridView3.Size = new System.Drawing.Size(1172, 253);
            this.dataGridView3.TabIndex = 0;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.radioButton7);
            this.groupBox7.Controls.Add(this.radioButton6);
            this.groupBox7.Controls.Add(this.radioButton5);
            this.groupBox7.Controls.Add(this.label12);
            this.groupBox7.Location = new System.Drawing.Point(3, 6);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(1175, 214);
            this.groupBox7.TabIndex = 0;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Tùy chọn Thống kê";
            // 
            // radioButton7
            // 
            this.radioButton7.AutoSize = true;
            this.radioButton7.Location = new System.Drawing.Point(194, 117);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.Size = new System.Drawing.Size(349, 25);
            this.radioButton7.TabIndex = 3;
            this.radioButton7.TabStop = true;
            this.radioButton7.Text = "Thống kê những độc giả trả sách đúng hạn";
            this.radioButton7.UseVisualStyleBackColor = true;
            // 
            // radioButton6
            // 
            this.radioButton6.AutoSize = true;
            this.radioButton6.Location = new System.Drawing.Point(194, 80);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(317, 25);
            this.radioButton6.TabIndex = 2;
            this.radioButton6.TabStop = true;
            this.radioButton6.Text = "Thống kê những độc giả chưa trả sách";
            this.radioButton6.UseVisualStyleBackColor = true;
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Location = new System.Drawing.Point(194, 39);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(323, 25);
            this.radioButton5.TabIndex = 1;
            this.radioButton5.TabStop = true;
            this.radioButton5.Text = "Thống kê những độc giả đã mượn sách";
            this.radioButton5.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(26, 41);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(122, 21);
            this.label12.TabIndex = 0;
            this.label12.Text = "Thống kê theo:";
            // 
            // QL_MuonTra
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1204, 706);
            this.Controls.Add(this.tabControl1);
            this.Name = "QL_MuonTra";
            this.Text = "QL_MuonTra";
            this.Load += new System.EventHandler(this.QL_MuonTra_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.gbMuonSach.ResumeLayout(false);
            this.gbMuonSach.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox gbMuonSach;
        private System.Windows.Forms.DateTimePicker tbNgayHanTra1;
        private System.Windows.Forms.DateTimePicker tbNgayMuon1;
        private System.Windows.Forms.TextBox tbNhanVien1;
        private System.Windows.Forms.TextBox tbMaThe1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.DateTimePicker tbNgayTra2;
        private System.Windows.Forms.TextBox tbCuonSach2;
        private System.Windows.Forms.TextBox tbNhanVien2;
        private System.Windows.Forms.TextBox tbMaThe2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox tbTinhTrang1;
        private System.Windows.Forms.TextBox tbSoTrang1;
        private System.Windows.Forms.TextBox tbTenSach1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbCuonSach1;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox tbMaKeSach1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tbMaDauSach1;
        private System.Windows.Forms.TextBox tbTTCuonSach1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox tbMaKeSach2;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox tbMaDauSach2;
        private System.Windows.Forms.TextBox tbTTCuonSach2;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox tbTinhTrang2;
        private System.Windows.Forms.TextBox tbSoTrang2;
        private System.Windows.Forms.TextBox tbTenSach2;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
    }
}