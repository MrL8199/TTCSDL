﻿namespace QLTV.GUI.SACH
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabcontrol = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label24 = new System.Windows.Forms.Label();
            this.dtgv_dsTacGia = new System.Windows.Forms.DataGridView();
            this.btnLuuTG = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.btnHuyTG = new System.Windows.Forms.Button();
            this.btnXoaTG = new System.Windows.Forms.Button();
            this.btnSuaTG = new System.Windows.Forms.Button();
            this.btnThemTG = new System.Windows.Forms.Button();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.tbMaTG = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.tbTenTG = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.btnTimKiemTacGia = new System.Windows.Forms.Button();
            this.tbKeywordTacGia = new System.Windows.Forms.TextBox();
            this.rdbTenTG = new System.Windows.Forms.RadioButton();
            this.rdbMaTG = new System.Windows.Forms.RadioButton();
            this.label27 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label21 = new System.Windows.Forms.Label();
            this.dtgv_NXB = new System.Windows.Forms.DataGridView();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.btnTimKiemNXB = new System.Windows.Forms.Button();
            this.tbKeywordNXB = new System.Windows.Forms.TextBox();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.radioButton8 = new System.Windows.Forms.RadioButton();
            this.label22 = new System.Windows.Forms.Label();
            this.button30 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.tbSdtNXB = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.tbTenNXB = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.tbMaNXB = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.tbDiaChiNXB = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label15 = new System.Windows.Forms.Label();
            this.dtgv_TheLoai = new System.Windows.Forms.DataGridView();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.btnTimKiemTheloai = new System.Windows.Forms.Button();
            this.tbKeywordTheLoai = new System.Windows.Forms.TextBox();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.label19 = new System.Windows.Forms.Label();
            this.button22 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.tbMaKeSach = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.tbTenTheLoai = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.label10 = new System.Windows.Forms.Label();
            this.dtgv_DauSach = new System.Windows.Forms.DataGridView();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnTimKiemDauSach = new System.Windows.Forms.Button();
            this.tbKeywordDauSach = new System.Windows.Forms.TextBox();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.label11 = new System.Windows.Forms.Label();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.tbMaNXB_DauSach = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.tbMaDauSach = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.tbTenDauSach = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.label9 = new System.Windows.Forms.Label();
            this.dtgv_CuonSach = new System.Windows.Forms.DataGridView();
            this.Search = new System.Windows.Forms.GroupBox();
            this.btnTimKiemCuonSach = new System.Windows.Forms.Button();
            this.tbKeywordCuonSach = new System.Windows.Forms.TextBox();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.label8 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tbMaKeSach_CuonSach = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tbMaDauSach_CuonSach = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tbSoTrang = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbTinhTrang = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tbMaCuonSach = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tbTenCuonSach = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.label12 = new System.Windows.Forms.Label();
            this.dtgv_thongke = new System.Windows.Forms.DataGridView();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radioButton12 = new System.Windows.Forms.RadioButton();
            this.radioButton11 = new System.Windows.Forms.RadioButton();
            this.button8 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.tabcontrol.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_dsTacGia)).BeginInit();
            this.groupBox10.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_NXB)).BeginInit();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_TheLoai)).BeginInit();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_DauSach)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_CuonSach)).BeginInit();
            this.Search.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_thongke)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabcontrol
            // 
            this.tabcontrol.Controls.Add(this.tabPage1);
            this.tabcontrol.Controls.Add(this.tabPage2);
            this.tabcontrol.Controls.Add(this.tabPage3);
            this.tabcontrol.Controls.Add(this.tabPage4);
            this.tabcontrol.Controls.Add(this.tabPage5);
            this.tabcontrol.Controls.Add(this.tabPage6);
            this.tabcontrol.Location = new System.Drawing.Point(-2, -2);
            this.tabcontrol.Name = "tabcontrol";
            this.tabcontrol.SelectedIndex = 0;
            this.tabcontrol.Size = new System.Drawing.Size(1002, 542);
            this.tabcontrol.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label24);
            this.tabPage1.Controls.Add(this.dtgv_dsTacGia);
            this.tabPage1.Controls.Add(this.btnLuuTG);
            this.tabPage1.Controls.Add(this.button17);
            this.tabPage1.Controls.Add(this.btnHuyTG);
            this.tabPage1.Controls.Add(this.btnXoaTG);
            this.tabPage1.Controls.Add(this.btnSuaTG);
            this.tabPage1.Controls.Add(this.btnThemTG);
            this.tabPage1.Controls.Add(this.groupBox10);
            this.tabPage1.Controls.Add(this.groupBox9);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(994, 516);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Tác Giả ";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(10, 260);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(94, 13);
            this.label24.TabIndex = 74;
            this.label24.Text = "Danh sách tác giả";
            // 
            // dtgv_dsTacGia
            // 
            this.dtgv_dsTacGia.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgv_dsTacGia.Location = new System.Drawing.Point(11, 276);
            this.dtgv_dsTacGia.Name = "dtgv_dsTacGia";
            this.dtgv_dsTacGia.Size = new System.Drawing.Size(977, 233);
            this.dtgv_dsTacGia.TabIndex = 73;
            this.dtgv_dsTacGia.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgv_dsTacGia_CellClick);
            // 
            // btnLuuTG
            // 
            this.btnLuuTG.BackColor = System.Drawing.Color.Green;
            this.btnLuuTG.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLuuTG.ForeColor = System.Drawing.Color.White;
            this.btnLuuTG.Location = new System.Drawing.Point(778, 214);
            this.btnLuuTG.Name = "btnLuuTG";
            this.btnLuuTG.Size = new System.Drawing.Size(75, 32);
            this.btnLuuTG.TabIndex = 72;
            this.btnLuuTG.Text = "Lưu";
            this.btnLuuTG.UseVisualStyleBackColor = false;
            this.btnLuuTG.Click += new System.EventHandler(this.btnLuuTG_Click);
            // 
            // button17
            // 
            this.button17.BackColor = System.Drawing.Color.Green;
            this.button17.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button17.ForeColor = System.Drawing.Color.Yellow;
            this.button17.Location = new System.Drawing.Point(914, 214);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(75, 32);
            this.button17.TabIndex = 71;
            this.button17.Text = "<<";
            this.button17.UseVisualStyleBackColor = false;
            // 
            // btnHuyTG
            // 
            this.btnHuyTG.BackColor = System.Drawing.Color.Green;
            this.btnHuyTG.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHuyTG.ForeColor = System.Drawing.Color.White;
            this.btnHuyTG.Location = new System.Drawing.Point(847, 214);
            this.btnHuyTG.Name = "btnHuyTG";
            this.btnHuyTG.Size = new System.Drawing.Size(75, 32);
            this.btnHuyTG.TabIndex = 70;
            this.btnHuyTG.Text = "Hủy";
            this.btnHuyTG.UseVisualStyleBackColor = false;
            this.btnHuyTG.Click += new System.EventHandler(this.btnHuy_Click);
            // 
            // btnXoaTG
            // 
            this.btnXoaTG.BackColor = System.Drawing.Color.Green;
            this.btnXoaTG.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoaTG.ForeColor = System.Drawing.Color.White;
            this.btnXoaTG.Location = new System.Drawing.Point(709, 214);
            this.btnXoaTG.Name = "btnXoaTG";
            this.btnXoaTG.Size = new System.Drawing.Size(75, 32);
            this.btnXoaTG.TabIndex = 69;
            this.btnXoaTG.Text = "Xóa";
            this.btnXoaTG.UseVisualStyleBackColor = false;
            this.btnXoaTG.Click += new System.EventHandler(this.btnXoaTG_Click);
            // 
            // btnSuaTG
            // 
            this.btnSuaTG.BackColor = System.Drawing.Color.Green;
            this.btnSuaTG.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuaTG.ForeColor = System.Drawing.Color.White;
            this.btnSuaTG.Location = new System.Drawing.Point(637, 214);
            this.btnSuaTG.Name = "btnSuaTG";
            this.btnSuaTG.Size = new System.Drawing.Size(75, 32);
            this.btnSuaTG.TabIndex = 68;
            this.btnSuaTG.Text = "Sửa";
            this.btnSuaTG.UseVisualStyleBackColor = false;
            this.btnSuaTG.Click += new System.EventHandler(this.btnSua_Click);
            // 
            // btnThemTG
            // 
            this.btnThemTG.BackColor = System.Drawing.Color.Green;
            this.btnThemTG.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThemTG.ForeColor = System.Drawing.Color.White;
            this.btnThemTG.Location = new System.Drawing.Point(565, 214);
            this.btnThemTG.Name = "btnThemTG";
            this.btnThemTG.Size = new System.Drawing.Size(75, 32);
            this.btnThemTG.TabIndex = 67;
            this.btnThemTG.Text = "Thêm";
            this.btnThemTG.UseVisualStyleBackColor = false;
            this.btnThemTG.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // groupBox10
            // 
            this.groupBox10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.groupBox10.Controls.Add(this.tbMaTG);
            this.groupBox10.Controls.Add(this.label31);
            this.groupBox10.Controls.Add(this.tbTenTG);
            this.groupBox10.Controls.Add(this.label32);
            this.groupBox10.Enabled = false;
            this.groupBox10.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.groupBox10.Location = new System.Drawing.Point(289, 11);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(699, 197);
            this.groupBox10.TabIndex = 66;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Thông tin tác giả";
            // 
            // tbMaTG
            // 
            this.tbMaTG.Location = new System.Drawing.Point(124, 88);
            this.tbMaTG.Name = "tbMaTG";
            this.tbMaTG.Size = new System.Drawing.Size(202, 27);
            this.tbMaTG.TabIndex = 1;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(40, 91);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(78, 19);
            this.label31.TabIndex = 0;
            this.label31.Text = "Mã tác giả";
            // 
            // tbTenTG
            // 
            this.tbTenTG.Location = new System.Drawing.Point(439, 88);
            this.tbTenTG.Name = "tbTenTG";
            this.tbTenTG.Size = new System.Drawing.Size(215, 27);
            this.tbTenTG.TabIndex = 2;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(353, 92);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(80, 19);
            this.label32.TabIndex = 3;
            this.label32.Text = "Tên tác giả";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.btnTimKiemTacGia);
            this.groupBox9.Controls.Add(this.tbKeywordTacGia);
            this.groupBox9.Controls.Add(this.rdbTenTG);
            this.groupBox9.Controls.Add(this.rdbMaTG);
            this.groupBox9.Controls.Add(this.label27);
            this.groupBox9.Location = new System.Drawing.Point(3, 3);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(274, 205);
            this.groupBox9.TabIndex = 65;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Search";
            // 
            // btnTimKiemTacGia
            // 
            this.btnTimKiemTacGia.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnTimKiemTacGia.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTimKiemTacGia.ForeColor = System.Drawing.Color.Navy;
            this.btnTimKiemTacGia.Location = new System.Drawing.Point(22, 19);
            this.btnTimKiemTacGia.Name = "btnTimKiemTacGia";
            this.btnTimKiemTacGia.Size = new System.Drawing.Size(75, 33);
            this.btnTimKiemTacGia.TabIndex = 31;
            this.btnTimKiemTacGia.Text = "Tìm kiếm";
            this.btnTimKiemTacGia.UseVisualStyleBackColor = false;
            this.btnTimKiemTacGia.Click += new System.EventHandler(this.btnTimKiemTacGia_Click);
            // 
            // tbKeywordTacGia
            // 
            this.tbKeywordTacGia.Location = new System.Drawing.Point(46, 60);
            this.tbKeywordTacGia.Name = "tbKeywordTacGia";
            this.tbKeywordTacGia.Size = new System.Drawing.Size(195, 20);
            this.tbKeywordTacGia.TabIndex = 30;
            // 
            // rdbTenTG
            // 
            this.rdbTenTG.AutoSize = true;
            this.rdbTenTG.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.rdbTenTG.Location = new System.Drawing.Point(91, 154);
            this.rdbTenTG.Name = "rdbTenTG";
            this.rdbTenTG.Size = new System.Drawing.Size(79, 17);
            this.rdbTenTG.TabIndex = 29;
            this.rdbTenTG.TabStop = true;
            this.rdbTenTG.Text = "Tên tác giả";
            this.rdbTenTG.UseVisualStyleBackColor = true;
            // 
            // rdbMaTG
            // 
            this.rdbMaTG.AutoSize = true;
            this.rdbMaTG.Checked = true;
            this.rdbMaTG.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.rdbMaTG.Location = new System.Drawing.Point(91, 120);
            this.rdbMaTG.Name = "rdbMaTG";
            this.rdbMaTG.Size = new System.Drawing.Size(75, 17);
            this.rdbMaTG.TabIndex = 28;
            this.rdbMaTG.TabStop = true;
            this.rdbMaTG.Text = "Mã tác giả";
            this.rdbMaTG.UseVisualStyleBackColor = true;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(7, 96);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(74, 18);
            this.label27.TabIndex = 27;
            this.label27.Text = "Tìm theo :";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label21);
            this.tabPage2.Controls.Add(this.dtgv_NXB);
            this.tabPage2.Controls.Add(this.groupBox7);
            this.tabPage2.Controls.Add(this.button30);
            this.tabPage2.Controls.Add(this.button31);
            this.tabPage2.Controls.Add(this.button32);
            this.tabPage2.Controls.Add(this.button33);
            this.tabPage2.Controls.Add(this.button34);
            this.tabPage2.Controls.Add(this.button35);
            this.tabPage2.Controls.Add(this.groupBox8);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(994, 516);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "NXB";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(8, 265);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(84, 13);
            this.label21.TabIndex = 73;
            this.label21.Text = "Danh sách NXB";
            // 
            // dtgv_NXB
            // 
            this.dtgv_NXB.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgv_NXB.Location = new System.Drawing.Point(11, 281);
            this.dtgv_NXB.Name = "dtgv_NXB";
            this.dtgv_NXB.Size = new System.Drawing.Size(977, 219);
            this.dtgv_NXB.TabIndex = 72;
            this.dtgv_NXB.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgv_NXB_CellClick);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.btnTimKiemNXB);
            this.groupBox7.Controls.Add(this.tbKeywordNXB);
            this.groupBox7.Controls.Add(this.radioButton7);
            this.groupBox7.Controls.Add(this.radioButton8);
            this.groupBox7.Controls.Add(this.label22);
            this.groupBox7.Location = new System.Drawing.Point(-8, 17);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(274, 205);
            this.groupBox7.TabIndex = 71;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Search";
            // 
            // btnTimKiemNXB
            // 
            this.btnTimKiemNXB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnTimKiemNXB.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTimKiemNXB.ForeColor = System.Drawing.Color.Navy;
            this.btnTimKiemNXB.Location = new System.Drawing.Point(19, 19);
            this.btnTimKiemNXB.Name = "btnTimKiemNXB";
            this.btnTimKiemNXB.Size = new System.Drawing.Size(75, 33);
            this.btnTimKiemNXB.TabIndex = 32;
            this.btnTimKiemNXB.Text = "Tìm kiếm";
            this.btnTimKiemNXB.UseVisualStyleBackColor = false;
            this.btnTimKiemNXB.Click += new System.EventHandler(this.btnTimKiemNXB_Click);
            // 
            // tbKeywordNXB
            // 
            this.tbKeywordNXB.Location = new System.Drawing.Point(46, 60);
            this.tbKeywordNXB.Name = "tbKeywordNXB";
            this.tbKeywordNXB.Size = new System.Drawing.Size(195, 20);
            this.tbKeywordNXB.TabIndex = 30;
            // 
            // radioButton7
            // 
            this.radioButton7.AutoSize = true;
            this.radioButton7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.radioButton7.Location = new System.Drawing.Point(91, 154);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.Size = new System.Drawing.Size(69, 17);
            this.radioButton7.TabIndex = 29;
            this.radioButton7.TabStop = true;
            this.radioButton7.Text = "Tên NXB";
            this.radioButton7.UseVisualStyleBackColor = true;
            // 
            // radioButton8
            // 
            this.radioButton8.AutoSize = true;
            this.radioButton8.Checked = true;
            this.radioButton8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.radioButton8.Location = new System.Drawing.Point(91, 120);
            this.radioButton8.Name = "radioButton8";
            this.radioButton8.Size = new System.Drawing.Size(65, 17);
            this.radioButton8.TabIndex = 28;
            this.radioButton8.TabStop = true;
            this.radioButton8.Text = "Mã NXB";
            this.radioButton8.UseVisualStyleBackColor = true;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(7, 96);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(74, 18);
            this.label22.TabIndex = 27;
            this.label22.Text = "Tìm theo :";
            // 
            // button30
            // 
            this.button30.BackColor = System.Drawing.Color.Green;
            this.button30.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button30.ForeColor = System.Drawing.Color.White;
            this.button30.Location = new System.Drawing.Point(792, 219);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(75, 32);
            this.button30.TabIndex = 70;
            this.button30.Text = "Lưu";
            this.button30.UseVisualStyleBackColor = false;
            this.button30.Click += new System.EventHandler(this.btnLuuTG_Click);
            // 
            // button31
            // 
            this.button31.BackColor = System.Drawing.Color.Green;
            this.button31.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button31.ForeColor = System.Drawing.Color.Yellow;
            this.button31.Location = new System.Drawing.Point(928, 219);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(75, 32);
            this.button31.TabIndex = 69;
            this.button31.Text = "<<";
            this.button31.UseVisualStyleBackColor = false;
            // 
            // button32
            // 
            this.button32.BackColor = System.Drawing.Color.Green;
            this.button32.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button32.ForeColor = System.Drawing.Color.White;
            this.button32.Location = new System.Drawing.Point(861, 219);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(75, 32);
            this.button32.TabIndex = 68;
            this.button32.Text = "Hủy";
            this.button32.UseVisualStyleBackColor = false;
            this.button32.Click += new System.EventHandler(this.btnHuy_Click);
            // 
            // button33
            // 
            this.button33.BackColor = System.Drawing.Color.Green;
            this.button33.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button33.ForeColor = System.Drawing.Color.White;
            this.button33.Location = new System.Drawing.Point(723, 219);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(75, 32);
            this.button33.TabIndex = 67;
            this.button33.Text = "Xóa";
            this.button33.UseVisualStyleBackColor = false;
            this.button33.Click += new System.EventHandler(this.btnXoaTG_Click);
            // 
            // button34
            // 
            this.button34.BackColor = System.Drawing.Color.Green;
            this.button34.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button34.ForeColor = System.Drawing.Color.White;
            this.button34.Location = new System.Drawing.Point(651, 219);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(75, 32);
            this.button34.TabIndex = 66;
            this.button34.Text = "Sửa";
            this.button34.UseVisualStyleBackColor = false;
            this.button34.Click += new System.EventHandler(this.btnSua_Click);
            // 
            // button35
            // 
            this.button35.BackColor = System.Drawing.Color.Green;
            this.button35.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button35.ForeColor = System.Drawing.Color.White;
            this.button35.Location = new System.Drawing.Point(579, 219);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(75, 32);
            this.button35.TabIndex = 65;
            this.button35.Text = "Thêm";
            this.button35.UseVisualStyleBackColor = false;
            this.button35.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // groupBox8
            // 
            this.groupBox8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.groupBox8.Controls.Add(this.tbSdtNXB);
            this.groupBox8.Controls.Add(this.label25);
            this.groupBox8.Controls.Add(this.tbTenNXB);
            this.groupBox8.Controls.Add(this.label26);
            this.groupBox8.Controls.Add(this.tbMaNXB);
            this.groupBox8.Controls.Add(this.label28);
            this.groupBox8.Controls.Add(this.tbDiaChiNXB);
            this.groupBox8.Controls.Add(this.label29);
            this.groupBox8.Enabled = false;
            this.groupBox8.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.groupBox8.Location = new System.Drawing.Point(272, 17);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(731, 205);
            this.groupBox8.TabIndex = 64;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Thông tin NXB";
            // 
            // tbSdtNXB
            // 
            this.tbSdtNXB.Location = new System.Drawing.Point(451, 93);
            this.tbSdtNXB.Name = "tbSdtNXB";
            this.tbSdtNXB.Size = new System.Drawing.Size(127, 27);
            this.tbSdtNXB.TabIndex = 8;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(353, 96);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(38, 19);
            this.label25.TabIndex = 9;
            this.label25.Text = "SĐT ";
            // 
            // tbTenNXB
            // 
            this.tbTenNXB.Location = new System.Drawing.Point(140, 93);
            this.tbTenNXB.Name = "tbTenNXB";
            this.tbTenNXB.Size = new System.Drawing.Size(177, 27);
            this.tbTenNXB.TabIndex = 5;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(35, 96);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(63, 19);
            this.label26.TabIndex = 4;
            this.label26.Text = "Tên NXB";
            // 
            // tbMaNXB
            // 
            this.tbMaNXB.Location = new System.Drawing.Point(140, 43);
            this.tbMaNXB.Name = "tbMaNXB";
            this.tbMaNXB.Size = new System.Drawing.Size(177, 27);
            this.tbMaNXB.TabIndex = 1;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(35, 46);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(61, 19);
            this.label28.TabIndex = 0;
            this.label28.Text = "Mã NXB";
            // 
            // tbDiaChiNXB
            // 
            this.tbDiaChiNXB.Location = new System.Drawing.Point(449, 43);
            this.tbDiaChiNXB.Name = "tbDiaChiNXB";
            this.tbDiaChiNXB.Size = new System.Drawing.Size(243, 27);
            this.tbDiaChiNXB.TabIndex = 2;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(342, 46);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(87, 19);
            this.label29.TabIndex = 3;
            this.label29.Text = "Địa Chỉ NXB";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.label15);
            this.tabPage3.Controls.Add(this.dtgv_TheLoai);
            this.tabPage3.Controls.Add(this.groupBox6);
            this.tabPage3.Controls.Add(this.button22);
            this.tabPage3.Controls.Add(this.button23);
            this.tabPage3.Controls.Add(this.button24);
            this.tabPage3.Controls.Add(this.button25);
            this.tabPage3.Controls.Add(this.button26);
            this.tabPage3.Controls.Add(this.button27);
            this.tabPage3.Controls.Add(this.button28);
            this.tabPage3.Controls.Add(this.groupBox5);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(994, 516);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Thể Loại";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(12, 266);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(96, 13);
            this.label15.TabIndex = 66;
            this.label15.Text = "Danh sách thể loại";
            // 
            // dtgv_TheLoai
            // 
            this.dtgv_TheLoai.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgv_TheLoai.Location = new System.Drawing.Point(12, 285);
            this.dtgv_TheLoai.Name = "dtgv_TheLoai";
            this.dtgv_TheLoai.Size = new System.Drawing.Size(977, 219);
            this.dtgv_TheLoai.TabIndex = 65;
            this.dtgv_TheLoai.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgv_TheLoai_CellClick);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.btnTimKiemTheloai);
            this.groupBox6.Controls.Add(this.tbKeywordTheLoai);
            this.groupBox6.Controls.Add(this.radioButton5);
            this.groupBox6.Controls.Add(this.radioButton6);
            this.groupBox6.Controls.Add(this.label19);
            this.groupBox6.Location = new System.Drawing.Point(-7, 13);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(274, 205);
            this.groupBox6.TabIndex = 64;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Search";
            // 
            // btnTimKiemTheloai
            // 
            this.btnTimKiemTheloai.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnTimKiemTheloai.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTimKiemTheloai.ForeColor = System.Drawing.Color.Navy;
            this.btnTimKiemTheloai.Location = new System.Drawing.Point(19, 19);
            this.btnTimKiemTheloai.Name = "btnTimKiemTheloai";
            this.btnTimKiemTheloai.Size = new System.Drawing.Size(75, 33);
            this.btnTimKiemTheloai.TabIndex = 32;
            this.btnTimKiemTheloai.Text = "Tìm kiếm";
            this.btnTimKiemTheloai.UseVisualStyleBackColor = false;
            this.btnTimKiemTheloai.Click += new System.EventHandler(this.btnTimKiemTheloai_Click);
            // 
            // tbKeywordTheLoai
            // 
            this.tbKeywordTheLoai.Location = new System.Drawing.Point(46, 60);
            this.tbKeywordTheLoai.Name = "tbKeywordTheLoai";
            this.tbKeywordTheLoai.Size = new System.Drawing.Size(195, 20);
            this.tbKeywordTheLoai.TabIndex = 30;
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.radioButton5.Location = new System.Drawing.Point(91, 154);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(81, 17);
            this.radioButton5.TabIndex = 29;
            this.radioButton5.TabStop = true;
            this.radioButton5.Text = "Tên thể loại";
            this.radioButton5.UseVisualStyleBackColor = true;
            // 
            // radioButton6
            // 
            this.radioButton6.AutoSize = true;
            this.radioButton6.Checked = true;
            this.radioButton6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.radioButton6.Location = new System.Drawing.Point(91, 120);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(81, 17);
            this.radioButton6.TabIndex = 28;
            this.radioButton6.TabStop = true;
            this.radioButton6.Text = "Mã kệ sách";
            this.radioButton6.UseVisualStyleBackColor = true;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(7, 96);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(74, 18);
            this.label19.TabIndex = 27;
            this.label19.Text = "Tìm theo :";
            // 
            // button22
            // 
            this.button22.BackColor = System.Drawing.Color.Green;
            this.button22.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button22.ForeColor = System.Drawing.Color.White;
            this.button22.Location = new System.Drawing.Point(494, 211);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(90, 32);
            this.button22.TabIndex = 63;
            this.button22.Text = "Làm mới";
            this.button22.UseVisualStyleBackColor = false;
            // 
            // button23
            // 
            this.button23.BackColor = System.Drawing.Color.Green;
            this.button23.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button23.ForeColor = System.Drawing.Color.White;
            this.button23.Location = new System.Drawing.Point(791, 211);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(75, 32);
            this.button23.TabIndex = 62;
            this.button23.Text = "Lưu";
            this.button23.UseVisualStyleBackColor = false;
            this.button23.Click += new System.EventHandler(this.btnLuuTG_Click);
            // 
            // button24
            // 
            this.button24.BackColor = System.Drawing.Color.Green;
            this.button24.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button24.ForeColor = System.Drawing.Color.Yellow;
            this.button24.Location = new System.Drawing.Point(927, 211);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(75, 32);
            this.button24.TabIndex = 61;
            this.button24.Text = "<<";
            this.button24.UseVisualStyleBackColor = false;
            // 
            // button25
            // 
            this.button25.BackColor = System.Drawing.Color.Green;
            this.button25.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button25.ForeColor = System.Drawing.Color.White;
            this.button25.Location = new System.Drawing.Point(860, 211);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(75, 32);
            this.button25.TabIndex = 60;
            this.button25.Text = "Hủy";
            this.button25.UseVisualStyleBackColor = false;
            this.button25.Click += new System.EventHandler(this.btnHuy_Click);
            // 
            // button26
            // 
            this.button26.BackColor = System.Drawing.Color.Green;
            this.button26.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button26.ForeColor = System.Drawing.Color.White;
            this.button26.Location = new System.Drawing.Point(722, 211);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(75, 32);
            this.button26.TabIndex = 59;
            this.button26.Text = "Xóa";
            this.button26.UseVisualStyleBackColor = false;
            this.button26.Click += new System.EventHandler(this.btnXoaTG_Click);
            // 
            // button27
            // 
            this.button27.BackColor = System.Drawing.Color.Green;
            this.button27.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button27.ForeColor = System.Drawing.Color.White;
            this.button27.Location = new System.Drawing.Point(650, 211);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(75, 32);
            this.button27.TabIndex = 58;
            this.button27.Text = "Sửa";
            this.button27.UseVisualStyleBackColor = false;
            this.button27.Click += new System.EventHandler(this.btnSua_Click);
            // 
            // button28
            // 
            this.button28.BackColor = System.Drawing.Color.Green;
            this.button28.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button28.ForeColor = System.Drawing.Color.White;
            this.button28.Location = new System.Drawing.Point(578, 211);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(75, 32);
            this.button28.TabIndex = 57;
            this.button28.Text = "Thêm";
            this.button28.UseVisualStyleBackColor = false;
            this.button28.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.groupBox5.Controls.Add(this.tbMaKeSach);
            this.groupBox5.Controls.Add(this.label13);
            this.groupBox5.Controls.Add(this.tbTenTheLoai);
            this.groupBox5.Controls.Add(this.label14);
            this.groupBox5.Enabled = false;
            this.groupBox5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.groupBox5.Location = new System.Drawing.Point(303, 17);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(699, 197);
            this.groupBox5.TabIndex = 56;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Thông tin thể loại";
            // 
            // tbMaKeSach
            // 
            this.tbMaKeSach.Location = new System.Drawing.Point(131, 55);
            this.tbMaKeSach.Name = "tbMaKeSach";
            this.tbMaKeSach.Size = new System.Drawing.Size(177, 27);
            this.tbMaKeSach.TabIndex = 1;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(43, 59);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(82, 19);
            this.label13.TabIndex = 0;
            this.label13.Text = "Mã kệ sách";
            // 
            // tbTenTheLoai
            // 
            this.tbTenTheLoai.Location = new System.Drawing.Point(440, 55);
            this.tbTenTheLoai.Name = "tbTenTheLoai";
            this.tbTenTheLoai.Size = new System.Drawing.Size(215, 27);
            this.tbTenTheLoai.TabIndex = 2;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(354, 58);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(85, 19);
            this.label14.TabIndex = 3;
            this.label14.Text = "Tên thể loại";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.label10);
            this.tabPage4.Controls.Add(this.dtgv_DauSach);
            this.tabPage4.Controls.Add(this.groupBox3);
            this.tabPage4.Controls.Add(this.button9);
            this.tabPage4.Controls.Add(this.button10);
            this.tabPage4.Controls.Add(this.button11);
            this.tabPage4.Controls.Add(this.button12);
            this.tabPage4.Controls.Add(this.button13);
            this.tabPage4.Controls.Add(this.button14);
            this.tabPage4.Controls.Add(this.groupBox4);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(994, 516);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Đầu Sách ";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(11, 266);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(107, 13);
            this.label10.TabIndex = 58;
            this.label10.Text = "Danh sách đầu sách";
            // 
            // dtgv_DauSach
            // 
            this.dtgv_DauSach.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgv_DauSach.Location = new System.Drawing.Point(11, 285);
            this.dtgv_DauSach.Name = "dtgv_DauSach";
            this.dtgv_DauSach.Size = new System.Drawing.Size(977, 219);
            this.dtgv_DauSach.TabIndex = 57;
            this.dtgv_DauSach.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgv_DauSach_CellClick);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnTimKiemDauSach);
            this.groupBox3.Controls.Add(this.tbKeywordDauSach);
            this.groupBox3.Controls.Add(this.radioButton3);
            this.groupBox3.Controls.Add(this.radioButton4);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Location = new System.Drawing.Point(-8, 13);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(274, 205);
            this.groupBox3.TabIndex = 56;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Search";
            // 
            // btnTimKiemDauSach
            // 
            this.btnTimKiemDauSach.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnTimKiemDauSach.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTimKiemDauSach.ForeColor = System.Drawing.Color.Navy;
            this.btnTimKiemDauSach.Location = new System.Drawing.Point(10, 19);
            this.btnTimKiemDauSach.Name = "btnTimKiemDauSach";
            this.btnTimKiemDauSach.Size = new System.Drawing.Size(75, 33);
            this.btnTimKiemDauSach.TabIndex = 32;
            this.btnTimKiemDauSach.Text = "Tìm kiếm";
            this.btnTimKiemDauSach.UseVisualStyleBackColor = false;
            this.btnTimKiemDauSach.Click += new System.EventHandler(this.btnTimKiemDauSach_Click);
            // 
            // tbKeywordDauSach
            // 
            this.tbKeywordDauSach.Location = new System.Drawing.Point(46, 60);
            this.tbKeywordDauSach.Name = "tbKeywordDauSach";
            this.tbKeywordDauSach.Size = new System.Drawing.Size(195, 20);
            this.tbKeywordDauSach.TabIndex = 30;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.radioButton3.Location = new System.Drawing.Point(91, 154);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(97, 17);
            this.radioButton3.TabIndex = 29;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "Tên cuốn sách";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Checked = true;
            this.radioButton4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.radioButton4.Location = new System.Drawing.Point(91, 120);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(88, 17);
            this.radioButton4.TabIndex = 28;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "Mã đầu sách";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(7, 96);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(74, 18);
            this.label11.TabIndex = 27;
            this.label11.Text = "Tìm theo :";
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.Green;
            this.button9.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.ForeColor = System.Drawing.Color.White;
            this.button9.Location = new System.Drawing.Point(792, 215);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(75, 32);
            this.button9.TabIndex = 55;
            this.button9.Text = "Lưu";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.btnLuuTG_Click);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.Green;
            this.button10.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.ForeColor = System.Drawing.Color.Yellow;
            this.button10.Location = new System.Drawing.Point(928, 215);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(75, 32);
            this.button10.TabIndex = 54;
            this.button10.Text = "<<";
            this.button10.UseVisualStyleBackColor = false;
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.Green;
            this.button11.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button11.ForeColor = System.Drawing.Color.White;
            this.button11.Location = new System.Drawing.Point(861, 215);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(75, 32);
            this.button11.TabIndex = 53;
            this.button11.Text = "Hủy";
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.btnHuy_Click);
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.Green;
            this.button12.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button12.ForeColor = System.Drawing.Color.White;
            this.button12.Location = new System.Drawing.Point(723, 215);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(75, 32);
            this.button12.TabIndex = 52;
            this.button12.Text = "Xóa";
            this.button12.UseVisualStyleBackColor = false;
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.Green;
            this.button13.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button13.ForeColor = System.Drawing.Color.White;
            this.button13.Location = new System.Drawing.Point(651, 215);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(75, 32);
            this.button13.TabIndex = 51;
            this.button13.Text = "Sửa";
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.btnSua_Click);
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.Green;
            this.button14.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.ForeColor = System.Drawing.Color.White;
            this.button14.Location = new System.Drawing.Point(579, 215);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(75, 32);
            this.button14.TabIndex = 50;
            this.button14.Text = "Thêm";
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.groupBox4.Controls.Add(this.tbMaNXB_DauSach);
            this.groupBox4.Controls.Add(this.label16);
            this.groupBox4.Controls.Add(this.tbMaDauSach);
            this.groupBox4.Controls.Add(this.label17);
            this.groupBox4.Controls.Add(this.tbTenDauSach);
            this.groupBox4.Controls.Add(this.label18);
            this.groupBox4.Enabled = false;
            this.groupBox4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.groupBox4.Location = new System.Drawing.Point(272, 13);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(731, 205);
            this.groupBox4.TabIndex = 49;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Thông tin cuốn sách";
            // 
            // tbMaNXB_DauSach
            // 
            this.tbMaNXB_DauSach.Location = new System.Drawing.Point(379, 120);
            this.tbMaNXB_DauSach.Name = "tbMaNXB_DauSach";
            this.tbMaNXB_DauSach.Size = new System.Drawing.Size(136, 27);
            this.tbMaNXB_DauSach.TabIndex = 6;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(303, 123);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(61, 19);
            this.label16.TabIndex = 7;
            this.label16.Text = "Mã NXB";
            // 
            // tbMaDauSach
            // 
            this.tbMaDauSach.Location = new System.Drawing.Point(140, 43);
            this.tbMaDauSach.Name = "tbMaDauSach";
            this.tbMaDauSach.Size = new System.Drawing.Size(177, 27);
            this.tbMaDauSach.TabIndex = 1;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(35, 46);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(93, 19);
            this.label17.TabIndex = 0;
            this.label17.Text = "Mã đầu sách";
            // 
            // tbTenDauSach
            // 
            this.tbTenDauSach.Location = new System.Drawing.Point(449, 43);
            this.tbTenDauSach.Name = "tbTenDauSach";
            this.tbTenDauSach.Size = new System.Drawing.Size(215, 27);
            this.tbTenDauSach.TabIndex = 2;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(342, 46);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(95, 19);
            this.label18.TabIndex = 3;
            this.label18.Text = "Tên đầu sách";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.label9);
            this.tabPage5.Controls.Add(this.dtgv_CuonSach);
            this.tabPage5.Controls.Add(this.Search);
            this.tabPage5.Controls.Add(this.button6);
            this.tabPage5.Controls.Add(this.button5);
            this.tabPage5.Controls.Add(this.button4);
            this.tabPage5.Controls.Add(this.button3);
            this.tabPage5.Controls.Add(this.button2);
            this.tabPage5.Controls.Add(this.button1);
            this.tabPage5.Controls.Add(this.groupBox1);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(994, 516);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Cuốn Sách";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(11, 268);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(112, 13);
            this.label9.TabIndex = 58;
            this.label9.Text = "Danh sách cuốn sách";
            // 
            // dtgv_CuonSach
            // 
            this.dtgv_CuonSach.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgv_CuonSach.Location = new System.Drawing.Point(11, 287);
            this.dtgv_CuonSach.Name = "dtgv_CuonSach";
            this.dtgv_CuonSach.Size = new System.Drawing.Size(977, 215);
            this.dtgv_CuonSach.TabIndex = 57;
            this.dtgv_CuonSach.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgv_CuonSach_CellClick);
            // 
            // Search
            // 
            this.Search.Controls.Add(this.btnTimKiemCuonSach);
            this.Search.Controls.Add(this.tbKeywordCuonSach);
            this.Search.Controls.Add(this.radioButton2);
            this.Search.Controls.Add(this.radioButton1);
            this.Search.Controls.Add(this.label8);
            this.Search.Location = new System.Drawing.Point(-8, 15);
            this.Search.Name = "Search";
            this.Search.Size = new System.Drawing.Size(274, 205);
            this.Search.TabIndex = 56;
            this.Search.TabStop = false;
            this.Search.Text = "Search";
            // 
            // btnTimKiemCuonSach
            // 
            this.btnTimKiemCuonSach.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnTimKiemCuonSach.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTimKiemCuonSach.ForeColor = System.Drawing.Color.Navy;
            this.btnTimKiemCuonSach.Location = new System.Drawing.Point(10, 19);
            this.btnTimKiemCuonSach.Name = "btnTimKiemCuonSach";
            this.btnTimKiemCuonSach.Size = new System.Drawing.Size(75, 33);
            this.btnTimKiemCuonSach.TabIndex = 32;
            this.btnTimKiemCuonSach.Text = "Tìm kiếm";
            this.btnTimKiemCuonSach.UseVisualStyleBackColor = false;
            this.btnTimKiemCuonSach.Click += new System.EventHandler(this.btnTimKiemCuonSach_Click);
            // 
            // tbKeywordCuonSach
            // 
            this.tbKeywordCuonSach.Location = new System.Drawing.Point(46, 60);
            this.tbKeywordCuonSach.Name = "tbKeywordCuonSach";
            this.tbKeywordCuonSach.Size = new System.Drawing.Size(195, 20);
            this.tbKeywordCuonSach.TabIndex = 30;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.radioButton2.Location = new System.Drawing.Point(91, 154);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(97, 17);
            this.radioButton2.TabIndex = 29;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Tên cuốn sách";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Checked = true;
            this.radioButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.radioButton1.Location = new System.Drawing.Point(91, 120);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(93, 17);
            this.radioButton1.TabIndex = 28;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Mã cuốn sách";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(7, 96);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(74, 18);
            this.label8.TabIndex = 27;
            this.label8.Text = "Tìm theo :";
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.Green;
            this.button6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.Location = new System.Drawing.Point(792, 217);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 32);
            this.button6.TabIndex = 55;
            this.button6.Text = "Lưu";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.btnLuuTG_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Green;
            this.button5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.Yellow;
            this.button5.Location = new System.Drawing.Point(928, 217);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 32);
            this.button5.TabIndex = 54;
            this.button5.Text = "<<";
            this.button5.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Green;
            this.button4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(861, 217);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 32);
            this.button4.TabIndex = 53;
            this.button4.Text = "Hủy";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.btnHuy_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Green;
            this.button3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(723, 217);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 32);
            this.button3.TabIndex = 52;
            this.button3.Text = "Xóa";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.btnXoaTG_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Green;
            this.button2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(651, 217);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 32);
            this.button2.TabIndex = 51;
            this.button2.Text = "Sửa";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.btnSua_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Green;
            this.button1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(579, 217);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 32);
            this.button1.TabIndex = 50;
            this.button1.Text = "Thêm";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.groupBox1.Controls.Add(this.tbMaKeSach_CuonSach);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.tbMaDauSach_CuonSach);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.tbSoTrang);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.tbTinhTrang);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.tbMaCuonSach);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.tbTenCuonSach);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Enabled = false;
            this.groupBox1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.groupBox1.Location = new System.Drawing.Point(272, 15);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(731, 205);
            this.groupBox1.TabIndex = 49;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Thông tin cuốn sách";
            // 
            // tbMaKeSach_CuonSach
            // 
            this.tbMaKeSach_CuonSach.Location = new System.Drawing.Point(449, 149);
            this.tbMaKeSach_CuonSach.Name = "tbMaKeSach_CuonSach";
            this.tbMaKeSach_CuonSach.Size = new System.Drawing.Size(215, 27);
            this.tbMaKeSach_CuonSach.TabIndex = 10;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(342, 152);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(82, 19);
            this.label7.TabIndex = 11;
            this.label7.Text = "Mã kệ sách";
            // 
            // tbMaDauSach_CuonSach
            // 
            this.tbMaDauSach_CuonSach.Location = new System.Drawing.Point(449, 93);
            this.tbMaDauSach_CuonSach.Name = "tbMaDauSach_CuonSach";
            this.tbMaDauSach_CuonSach.Size = new System.Drawing.Size(215, 27);
            this.tbMaDauSach_CuonSach.TabIndex = 8;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(342, 96);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(93, 19);
            this.label6.TabIndex = 9;
            this.label6.Text = "Mã đầu sách";
            // 
            // tbSoTrang
            // 
            this.tbSoTrang.Location = new System.Drawing.Point(140, 93);
            this.tbSoTrang.Name = "tbSoTrang";
            this.tbSoTrang.Size = new System.Drawing.Size(73, 27);
            this.tbSoTrang.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(35, 96);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 19);
            this.label4.TabIndex = 4;
            this.label4.Text = "Số trang";
            // 
            // tbTinhTrang
            // 
            this.tbTinhTrang.Location = new System.Drawing.Point(140, 149);
            this.tbTinhTrang.Name = "tbTinhTrang";
            this.tbTinhTrang.Size = new System.Drawing.Size(136, 27);
            this.tbTinhTrang.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(35, 152);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 19);
            this.label5.TabIndex = 7;
            this.label5.Text = "Tình trạng";
            // 
            // tbMaCuonSach
            // 
            this.tbMaCuonSach.Location = new System.Drawing.Point(140, 43);
            this.tbMaCuonSach.Name = "tbMaCuonSach";
            this.tbMaCuonSach.Size = new System.Drawing.Size(177, 27);
            this.tbMaCuonSach.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(35, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mã cuốn sách";
            // 
            // tbTenCuonSach
            // 
            this.tbTenCuonSach.Location = new System.Drawing.Point(449, 43);
            this.tbTenCuonSach.Name = "tbTenCuonSach";
            this.tbTenCuonSach.Size = new System.Drawing.Size(215, 27);
            this.tbTenCuonSach.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(342, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 19);
            this.label2.TabIndex = 3;
            this.label2.Text = "Tên cuốn sách";
            // 
            // tabPage6
            // 
            this.tabPage6.BackColor = System.Drawing.Color.PapayaWhip;
            this.tabPage6.Controls.Add(this.label12);
            this.tabPage6.Controls.Add(this.dtgv_thongke);
            this.tabPage6.Controls.Add(this.groupBox2);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(994, 516);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Thống Kê";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(126, 248);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(43, 13);
            this.label12.TabIndex = 5;
            this.label12.Text = "Dữ liệu ";
            // 
            // dtgv_thongke
            // 
            this.dtgv_thongke.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgv_thongke.Location = new System.Drawing.Point(126, 267);
            this.dtgv_thongke.Name = "dtgv_thongke";
            this.dtgv_thongke.Size = new System.Drawing.Size(742, 228);
            this.dtgv_thongke.TabIndex = 4;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.groupBox2.Controls.Add(this.radioButton12);
            this.groupBox2.Controls.Add(this.radioButton11);
            this.groupBox2.Controls.Add(this.button8);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Location = new System.Drawing.Point(126, 22);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(742, 186);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Thống Kê ";
            // 
            // radioButton12
            // 
            this.radioButton12.AutoSize = true;
            this.radioButton12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton12.Location = new System.Drawing.Point(84, 112);
            this.radioButton12.Name = "radioButton12";
            this.radioButton12.Size = new System.Drawing.Size(367, 24);
            this.radioButton12.TabIndex = 4;
            this.radioButton12.TabStop = true;
            this.radioButton12.Text = "Thống kê số lượng sách của mỗi đầu sách ";
            this.radioButton12.UseVisualStyleBackColor = true;
            // 
            // radioButton11
            // 
            this.radioButton11.AutoSize = true;
            this.radioButton11.Checked = true;
            this.radioButton11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton11.Location = new System.Drawing.Point(84, 73);
            this.radioButton11.Name = "radioButton11";
            this.radioButton11.Size = new System.Drawing.Size(325, 24);
            this.radioButton11.TabIndex = 3;
            this.radioButton11.TabStop = true;
            this.radioButton11.Text = "Thống kê số lượng sách của mỗi NXB";
            this.radioButton11.UseVisualStyleBackColor = true;
            this.radioButton11.CheckedChanged += new System.EventHandler(this.radioButton11_CheckedChanged);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.Color.White;
            this.button8.Location = new System.Drawing.Point(485, 88);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(99, 27);
            this.button8.TabIndex = 2;
            this.button8.Text = "Thống Kê";
            this.button8.UseVisualStyleBackColor = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(35, 33);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 16);
            this.label3.TabIndex = 0;
            this.label3.Text = "Theo";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1001, 541);
            this.Controls.Add(this.tabcontrol);
            this.Name = "Form1";
            this.Text = "QuanLyDauSach";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabcontrol.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_dsTacGia)).EndInit();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_NXB)).EndInit();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_TheLoai)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_DauSach)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_CuonSach)).EndInit();
            this.Search.ResumeLayout(false);
            this.Search.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_thongke)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabcontrol;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.DataGridView dtgv_dsTacGia;
        private System.Windows.Forms.Button btnLuuTG;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button btnHuyTG;
        private System.Windows.Forms.Button btnXoaTG;
        private System.Windows.Forms.Button btnSuaTG;
        private System.Windows.Forms.Button btnThemTG;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.TextBox tbMaTG;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox tbTenTG;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Button btnTimKiemTacGia;
        private System.Windows.Forms.TextBox tbKeywordTacGia;
        private System.Windows.Forms.RadioButton rdbTenTG;
        private System.Windows.Forms.RadioButton rdbMaTG;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.DataGridView dtgv_NXB;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Button btnTimKiemNXB;
        private System.Windows.Forms.TextBox tbKeywordNXB;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.RadioButton radioButton8;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TextBox tbSdtNXB;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox tbTenNXB;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox tbMaNXB;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox tbDiaChiNXB;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.DataGridView dtgv_TheLoai;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button btnTimKiemTheloai;
        private System.Windows.Forms.TextBox tbKeywordTheLoai;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox tbMaKeSach;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox tbTenTheLoai;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DataGridView dtgv_DauSach;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnTimKiemDauSach;
        private System.Windows.Forms.TextBox tbKeywordDauSach;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox tbMaNXB_DauSach;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox tbMaDauSach;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox tbTenDauSach;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DataGridView dtgv_CuonSach;
        private System.Windows.Forms.GroupBox Search;
        private System.Windows.Forms.Button btnTimKiemCuonSach;
        private System.Windows.Forms.TextBox tbKeywordCuonSach;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox tbMaKeSach_CuonSach;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tbMaDauSach_CuonSach;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbSoTrang;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbTinhTrang;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbMaCuonSach;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbTenCuonSach;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.DataGridView dtgv_thongke;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton radioButton12;
        private System.Windows.Forms.RadioButton radioButton11;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Label label3;
    }
}